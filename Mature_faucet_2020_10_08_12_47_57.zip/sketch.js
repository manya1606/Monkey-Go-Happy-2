var bananaImage, obstacleImage, obstaclegroup, backimage, score

function preload() {
  backimage = loadImage ("jungle.jpg")
  player_running = loadAnimation ("Monkey_01", "Monkey_02", "Monkey_03", "Monkey_04", "Monkey_05", "Monkey_06", "Monkey_07", "Monkey_08", "Monkey_09", "Monkey_10") 
  bananaImage = loadImage ("banana.png")
  obstacleImage = loadImage ("stone.png")
}

function setup() {
  createCanvas(400, 400);
  
  backimage = createSprite (400,400)
  backimage.velocityX = 200, 200
  
  ground.visibility = false
  player_running.addAnimation = (player_running)
}

function draw() {
  background(220);
  
  if (obstaclegroup.isTouching(player_running)){
    score = score+2
    obstaclegroup.destroyEach = true 
  }
    
    var score = 0
    switch(score) {
      case 10: player.scale = 0.12;
              break;
      case 20: player.scale = 0.14;
              break;
      case 30: player.scale = 0.16;
              break;
      case 40: player.scale = 0.18;
              break;
      default: break;
  
  }
  
  if (obstaclegroup.isTouching (player_running)){
      player_running.scale = 0.2
      
}

stroke ("white")
textSize(20)
fill("white")
text("Score:" + score, 400,50)
  